LOVE2D Catalin Zima's shadows

This is "pixel-accuracy" 2D-shadows.
Shadows compute fully on the GPU's pixel-shaders.
Need GLSL 1.20 (OpenGL 2.1).

LÖVE 2D-framework: http://love2d.org
Catalin Zima's shadows: http://www.catalinzima.com/2010/07/my-technique-for-the-shader-based-dynamic-2d-shadows/
Sources: http://github.com/AntonioModer/LOVE2DCatalinZimaShadows

Used GLSL-shaders from: http://bitbucket.org/totorigolo/shadows
Thanks to:
  Catalin Zima (http://www.catalinzima.com/about/)
  Thomas Lacroix (http://plus.google.com/b/107248556103962831257/109936266256123891803/about?pageId=107248556103962831257)
